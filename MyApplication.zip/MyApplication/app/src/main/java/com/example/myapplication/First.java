package com.example.myapplication;


import android.content.Intent;
import android.support.annotation.*;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class First extends AppCompatActivity {

    EditText eid,pwd;
    private Button login;
    private DatabaseReference ref;

    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_first);
        eid = (EditText) findViewById(R.id.eid);
        pwd = (EditText) findViewById(R.id.pwd);
        FirebaseApp.initializeApp(this);
        database =FirebaseDatabase.getInstance();
        ref = database.getReference().child("Users");

        login =(Button)findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(SecActivity.this, "okok", Toast.LENGTH_LONG).show();
                String e = eid.getText().toString();
                final String p = pwd.getText().toString();

                if (ref.child(e) != null) {

                    ref.child(e).addValueEventListener(new ValueEventListener() {
                        //System.out.println("Hi");
                        @Override
                        public void onDataChange( DataSnapshot dataSnapshot) {
                            //Toast.makeText(SecActivity.this, "Lol", Toast.LENGTH_LONG).show();
                            //                    String p =pass.getText().toString();
                            Users conductor = dataSnapshot.getValue(Users.class);
                            if (p.equals(conductor.getPass())) {
                                Toast.makeText(First.this, "Login Successful", Toast.LENGTH_LONG).show();
                                Intent start = new Intent(First.this, MapActivity.class);
                                startActivity(start);
                            } else {
                                Toast.makeText(First.this, "Login UNSuccessful", Toast.LENGTH_LONG).show();

                            }
                        }

                        @Override
                        public void onCancelled( DatabaseError databaseError) {

                        }
                    });
                }
                else
                {
                    Toast.makeText(First.this,"Conductor does not exist",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
